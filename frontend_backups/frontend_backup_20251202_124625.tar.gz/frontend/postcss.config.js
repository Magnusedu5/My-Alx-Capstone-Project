// 📚 LESSON: PostCSS Configuration for Tailwind v4
// Tailwind v4 uses a new PostCSS plugin

export default {
  plugins: {
    '@tailwindcss/postcss': {},
  },
}
